// simple tenant usage unit tests
package testing
