package serversext

import (
	"github.com/gophercloud/gophercloud"
	"github.com/gophercloud/gophercloud/openstack"
	"github.com/gophercloud/gophercloud/openstack/blockstorage/v2/volumes"
	"github.com/gophercloud/gophercloud/openstack/compute/v2/extensions/bootwithscheduler"
	"github.com/gophercloud/gophercloud/openstack/compute/v2/servers"
	"github.com/gophercloud/gophercloud/openstack/networking/v2/networks"
)

func CreateServer(client *gophercloud.ServiceClient, opts servers.CreateOptsBuilder) (r servers.CreateResult) {
	if bsOpts, ok := opts.(bootwithscheduler.CreateOptsExt); ok {
		//检查networks资源
		err := CheckNetworks(client, bsOpts)
		if err != nil {
			r.Err = err
			return
		}

		//检查volumes资源
		//		err = CheckVolumes(client, bsOpts)
		//		if err != nil {
		//			r.Err = err
		//	        return
		//		}
	}

	r = servers.Create(client, opts)
	return
}

//检测网络资源
func CheckNetworks(client *gophercloud.ServiceClient, opts bootwithscheduler.CreateOptsExt) error {
	//创建network client
	networkClient, err := openstack.NewNetworkV2(client.ProviderClient, gophercloud.EndpointOpts{})
	if err != nil {
		return err
	}

	base, err := opts.CreateOptsBuilder.ToServerCreateMap()
	if err != nil {
		return err
	}
	serverMap := base["server"].(map[string]interface{})
	nws := serverMap["networks"].([]map[string]interface{})
	//fmt.Println(networks)

	//整理过的network,uuid和其数量
	sortedNetworks := make(map[string]int)
	for _, n := range nws {
		if v, ok := n["uuid"]; ok {
			uuid, _ := v.(string)
			if uuid != "" {
				if _, ok := sortedNetworks[uuid]; ok {
					sortedNetworks[uuid]++
				} else {
					sortedNetworks[uuid] = 1
				}
			}
		}
	}

	//fmt.Println("sortedNetworks:", sortedNetworks)

	for uuid, needIps := range sortedNetworks {
		ia, err := networks.GetNetworkIpAvailabilities(networkClient, uuid)
		if err != nil {
			return err
		}

		availIps := ia.NetworkIpAvail.TotalIps - ia.NetworkIpAvail.UsedIps
		//fmt.Println("availIps:", availIps)
		//fmt.Println("needIps:", needIps)
		if availIps < needIps {
			return &gophercloud.UnifiedError{
				ErrCode:    "Ecs.1525",
				ErrMessage: "Insufficient IP addresses on the network.",
			}
		}

		continue
	}

	return nil
}

//检测存储资源
func CheckVolumes(client *gophercloud.ServiceClient, opts bootwithscheduler.CreateOptsExt) error {
	//创建blockstorage client
	bsClient, err := openstack.NewBlockStorageV2(client.ProviderClient, gophercloud.EndpointOpts{})
	if err != nil {
		return err
	}

	//计算需要的资源
	vNeed := 0
	gNeed := 0
	for _, bd := range opts.BlockDevice {
		if bd.SourceType != "volume" && bd.VolumeSize != 0 {
			vNeed++
			gNeed += bd.VolumeSize
		}
	}

	//计算现有的资源
	projectId := client.ProviderClient.GetProjectId()
	qs, err := volumes.GetQuotaSet(bsClient, projectId)
	if err != nil {
		return err
	}

	var vLimit, vInUse, gLimit, gInUse int
	if _, ok := qs.QuoSet.Volumes["limit"]; ok {
		vLimit = qs.QuoSet.Volumes["limit"]
	}
	if _, ok := qs.QuoSet.Volumes["in_use"]; ok {
		vInUse = qs.QuoSet.Volumes["in_use"]
	}
	if _, ok := qs.QuoSet.Gigabytes["limit"]; ok {
		gLimit = qs.QuoSet.Gigabytes["limit"]
	}
	if _, ok := qs.QuoSet.Gigabytes["in_use"]; ok {
		gInUse = qs.QuoSet.Gigabytes["in_use"]
	}

	//	fmt.Println("vNeed:", vNeed)
	//	fmt.Println("gNeed:", gNeed)
	//	fmt.Println("vLimit:", vLimit)
	//	fmt.Println("vInUse:", vInUse)
	//	fmt.Println("gLimit:", gLimit)
	//	fmt.Println("gInUse:", gInUse)

	//计算是否满足需要
	ue := &gophercloud.UnifiedError{
		ErrCode:    "Ecs.1524",
		ErrMessage: "Instance resource is temporarily sold out.",
	}

	if (vLimit != -1) && ((vLimit - vInUse) < vNeed) {
		return ue
	}

	if (gLimit != -1) && ((gLimit - gInUse) < gNeed) {
		return ue
	}

	return nil
}

/*
//判断资源是否已满，创建server前判断。
func CheckHostAvailable(client *gophercloud.ServiceClient) (bool, error) {

	//查询所有status为error的servers
	listOpts := servers.ListOpts{
		Status: "ERROR",
	}

	allPages, err := servers.List(client, listOpts).AllPages()
	if nil != err {
		return true, err
	}

	allServers, err := servers.ExtractServers(allPages)
	if nil != err {
		return true, err
	}

	if 0 == len(allServers) {
		return true, err
	}

	for _, s := range allServers {
		b := strings.Contains(s.Fault.Message, "There are not enough hosts available")
		if b {
			return false, err
		}
	}

	return true, err
}
*/
