package cloudservers

import "github.com/gophercloud/gophercloud"

func createURL(client *gophercloud.ServiceClient) string {
	return client.ServiceURL("cloudservers")
}

func jobURL(c *gophercloud.ServiceClient, jobId string) string {
	return c.ServiceURL("jobs", jobId)
}
