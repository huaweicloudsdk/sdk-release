// Package lbaas provides information and interaction with the Load Balancer
// as a Service extension for the OpenStack Networking service.
package lbaas
