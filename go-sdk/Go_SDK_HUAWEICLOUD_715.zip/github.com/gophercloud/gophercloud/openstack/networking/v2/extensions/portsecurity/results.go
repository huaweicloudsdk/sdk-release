package portsecurity

type PortSecurityExt struct {
	// PortSecurityEnabled specifies whether port security is enabled or
	// disabled.
	PortSecurityEnabled bool `json:"port_security_enabled"`
}
