// swauth unit tests
package testing
