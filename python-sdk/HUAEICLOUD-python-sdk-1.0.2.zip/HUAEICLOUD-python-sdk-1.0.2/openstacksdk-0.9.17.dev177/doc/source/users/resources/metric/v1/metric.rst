openstack.metric.v1.metric
==========================

.. automodule:: openstack.metric.v1.metric

The Metric Class
----------------

The ``Metric`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.metric.v1.metric.Metric
   :members:
