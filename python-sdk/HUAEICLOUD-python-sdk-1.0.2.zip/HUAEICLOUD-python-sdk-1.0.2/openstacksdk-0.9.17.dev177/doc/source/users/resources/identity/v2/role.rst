openstack.identity.v2.role
==========================

.. automodule:: openstack.identity.v2.role

The Role Class
--------------

The ``Role`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.identity.v2.role.Role
   :members:
