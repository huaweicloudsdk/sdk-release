openstack.network.v2.network
============================

.. automodule:: openstack.network.v2.agent

The Agent Class
-----------------

The ``Agent`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.agent.Agent
   :members:
