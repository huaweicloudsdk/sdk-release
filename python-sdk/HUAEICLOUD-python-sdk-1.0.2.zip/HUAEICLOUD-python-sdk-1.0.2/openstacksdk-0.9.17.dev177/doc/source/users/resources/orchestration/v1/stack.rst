openstack.orchestration.v1.stack
================================

.. automodule:: openstack.orchestration.v1.stack

The Stack Class
---------------

The ``Stack`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.orchestration.v1.stack.Stack
   :members:
