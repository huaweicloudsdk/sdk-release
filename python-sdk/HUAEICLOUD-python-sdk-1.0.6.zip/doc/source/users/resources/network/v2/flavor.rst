openstack.network.v2.flavor
===========================

.. automodule:: openstack.network.v2.flavor

The Flavor Class
----------------

The ``Flavor`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.flavor.Flavor
   :members:
