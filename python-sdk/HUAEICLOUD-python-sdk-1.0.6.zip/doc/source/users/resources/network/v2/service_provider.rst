openstack.network.v2.service_provider
=====================================

.. automodule:: openstack.network.v2.service_provider

The Service Provider Class
--------------------------

The ``Service Provider`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.service_provider.ServiceProvider
   :members:
