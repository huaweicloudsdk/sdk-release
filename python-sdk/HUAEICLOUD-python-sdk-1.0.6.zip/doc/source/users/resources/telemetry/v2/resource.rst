openstack.telemetry.v2.resource
===============================

.. automodule:: openstack.telemetry.v2.resource

The Resource Class
------------------

The ``Resource`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.telemetry.v2.resource.Resource
   :members:
