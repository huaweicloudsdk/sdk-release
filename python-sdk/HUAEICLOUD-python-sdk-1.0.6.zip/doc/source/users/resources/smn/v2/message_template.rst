openstack.smn.v2.message_template
=================================

.. automodule:: openstack.smn.v2.message_template

The MessageTemplate Class
-------------------------

The ``MessageTemplate`` class inherits from
    :class:`~openstack.smn.v2.smnresource.Resource`.

.. autoclass:: openstack.smn.v2.message_template.MessageTemplate
   :members:
