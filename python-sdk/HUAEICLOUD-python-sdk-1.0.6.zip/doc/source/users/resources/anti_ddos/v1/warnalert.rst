openstack.anti_ddos.v1.warnalert
================================

.. automodule:: openstack.anti_ddos.v1.warnalert

The AlertConfig Class
-------------------------

The ``AlertConfig`` class inherits from
      :class:`~openstack.resource2.Resource`.

.. autoclass:: openstack.anti_ddos.v1.warnalert.AlertConfig
   :members:
