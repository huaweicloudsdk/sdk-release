openstack.orchestration.v1.resource
===================================

.. automodule:: openstack.orchestration.v1.resource

The Resource Class
------------------

The ``Resource`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.orchestration.v1.resource.Resource
   :members:
