openstack.network.v2.segment
============================

.. automodule:: openstack.network.v2.segment

The Segment Class
-----------------

The ``Segment`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.segment.Segment
   :members:
