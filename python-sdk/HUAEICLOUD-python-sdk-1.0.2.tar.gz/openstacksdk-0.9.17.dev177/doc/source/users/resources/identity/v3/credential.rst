openstack.identity.v3.credential
================================

.. automodule:: openstack.identity.v3.credential

The Credential Class
--------------------

The ``Credential`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.identity.v3.credential.Credential
   :members:
