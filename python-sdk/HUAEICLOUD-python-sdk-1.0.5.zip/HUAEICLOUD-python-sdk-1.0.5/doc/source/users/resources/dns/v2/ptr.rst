openstack.dns.v2.ptr
==========================

.. automodule:: openstack.dns.v2.ptr

The PTR Class
--------------

The ``PTR`` class inherits from :class:`~openstack.resource2.Resource`.

.. autoclass:: openstack.dns.v2.ptr.PTR
   :members:
