openstack.bare_metal.v1.port_group
==================================

.. automodule:: openstack.bare_metal.v1.port_group

The PortGroup Class
-------------------

The ``PortGroup`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.bare_metal.v1.port_group.PortGroup
   :members:
