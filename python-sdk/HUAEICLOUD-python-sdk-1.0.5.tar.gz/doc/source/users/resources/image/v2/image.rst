openstack.image.v2.image
========================

.. automodule:: openstack.image.v2.image

The Image Class
---------------

The ``Image`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.image.v2.image.Image
   :members:
