openstack.image.v1.image
========================

.. automodule:: openstack.image.v1.image

The Image Class
---------------

The ``Image`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.image.v1.image.Image
   :members:
