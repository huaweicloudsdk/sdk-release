openstack.dns.v2.recordset
==========================

.. automodule:: openstack.dns.v2.recordset

The Recordset Class
--------------

The ``Recordset`` class inherits from :class:`~openstack.resource2.Resource`.

.. autoclass:: openstack.dns.v2.recordset.Recordset
   :members:


The Recordsets Class
--------------

The ``Recordsets`` class inherits from :class:`~openstack.resource2.Resource`.

.. autoclass:: openstack.dns.v2.recordset.Recordsets
   :members:
