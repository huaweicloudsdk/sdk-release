openstack.workflow.v2.workflow
==============================

.. automodule:: openstack.workflow.v2.workflow

The Workflow Class
------------------

The ``Workflow`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.workflow.v2.workflow.Workflow
   :members:
