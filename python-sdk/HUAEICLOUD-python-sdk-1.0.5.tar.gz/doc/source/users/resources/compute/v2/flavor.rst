openstack.compute.v2.flavor
============================

.. automodule:: openstack.compute.v2.flavor

The Flavor Class
----------------

The ``Flavor`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.compute.v2.flavor.Flavor
   :members:

The FlavorDetail Class
----------------------

The ``FlavorDetail`` class inherits from
:class:`~openstack.compute.v2.flavor.Flavor`.

.. autoclass:: openstack.compute.v2.flavor.FlavorDetail
   :members:
