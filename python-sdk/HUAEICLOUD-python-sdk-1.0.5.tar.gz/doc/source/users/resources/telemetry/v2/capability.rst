openstack.telemetry.v2.capability
=================================

.. automodule:: openstack.telemetry.v2.capability

The Capability Class
--------------------

The ``Capability`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.telemetry.v2.capability.Capability
   :members:
