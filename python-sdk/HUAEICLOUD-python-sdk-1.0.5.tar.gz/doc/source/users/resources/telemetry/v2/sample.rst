openstack.telemetry.v2.sample
=============================

.. automodule:: openstack.telemetry.v2.sample

The Sample Class
----------------

The ``Sample`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.telemetry.v2.sample.Sample
   :members:
