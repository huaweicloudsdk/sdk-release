openstack.network.v2.security_group
===================================

.. automodule:: openstack.network.v2.security_group

The SecurityGroup Class
-----------------------

The ``SecurityGroup`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.security_group.SecurityGroup
   :members:
