openstack.network.v2.floating_ip
================================

.. automodule:: openstack.network.v2.floating_ip

The FloatingIP Class
--------------------

The ``FloatingIP`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.floating_ip.FloatingIP
   :members:
