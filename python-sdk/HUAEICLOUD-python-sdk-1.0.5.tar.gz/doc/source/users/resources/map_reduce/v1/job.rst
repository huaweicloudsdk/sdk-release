openstack.map_reduce.v1.job
==========================

.. automodule:: openstack.map_reduce.v1.job

The Job Class
--------------

The ``Job`` class inherits from :class:`~openstack.resource2.Resource`.

.. autoclass:: openstack.map_reduce.v1.job.Job
   :members:
